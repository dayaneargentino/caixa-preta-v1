# Licença Creative Commons Atribuição-NãoComercial-SemDerivações 4.0 Internacional

**SPDX-License-Identifier: CC-BY-NC-ND-4.0**

Copyright © 2026 Dayane Argentino. Reservados os direitos não expressamente concedidos.

Os **elementos originais desta obra** (textos, estrutura narrativa, composições visuais e código original) são disponibilizados nos termos da licença **Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International — CC BY-NC-ND 4.0**.

Texto oficial e juridicamente vinculante: <https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode.pt>

Resumo informativo (não substitui a licença oficial):
- Pode compartilhar a obra original, mantendo a atribuição adequada e indicação da licença.
- Não pode fazer uso comercial da obra sob esta licença.
- Não pode distribuir versões modificadas ou adaptações da obra sob esta licença.
- Todos os direitos não concedidos continuam reservados.

**Atenção aos conteúdos de terceiros:** qualquer áudio, vídeo, imagem, fonte, biblioteca ou outro elemento de terceiros mantém seus próprios direitos e licenças; esta licença não os substitui. Consulte os créditos e atribuições do projeto. Não se presume que todos os recursos incluídos sejam de titularidade da autora.

**Limites técnicos:** uma licença define permissões jurídicas, não bloqueia a cópia, a edição local ou os forks de um repositório público. O GitHub restringe alterações diretas no repositório à proprietária e a quem ela conceder acesso de escrita.
